#include "lista_dupla.h"

struct lista_dupla{
    int info;
    struct lista_dupla* ant;
    struct lista_dupla* prox;
    
};

/* inserção no inicio */
Lista_dupla* lst_insere(Lista_dupla* l, int v){
    Lista_dupla* novo = (Lista_dupla*) malloc (sizeof(Lista_dupla));
    novo->info = v;
    novo->prox = l;
    novo->ant = NULL;
    /* Verifica se lista não está vazia */
    if (l != NULL)
    {
        l->ant = novo;
    }

    return novo;    
}

Lista_dupla* lst_busca(Lista_dupla* l, int v){
    Lista_dupla* p;
    for (p=l; p != NULL; p->prox)
    {
        if (p->info == v)
            return p;
        return NULL;
    }
    
}

Lista_dupla* lst_retira(Lista_dupla* l, int v){
    Lista_dupla* p = lst_busca(l, v);

    if (p == NULL) return 1;

    if (l == p) l = p->prox;

    else p->ant->prox = p->prox;

    if (p->prox != NULL) p->prox->ant = p->ant;

    free(p);
    return l;  

}

void lst_circ_imprime(Lista_dupla* l){
    Lista_dupla* p = l;
    if(p) do {
        printf("%d\n", p->info);
        p = p->ant;
    }while(p != l);
}